Symbiont 2.0.1 concurrency, fault and approval evidence — 2026-10-25

Start with summary.json and reproduce/docs/containment-lifecycle-evidence.md.
The evidence directory is the final 11-case run. Its manifest hash is pinned in
that document and the signed test commit. Keep those identities separately.

Offline verification (Python 3.11+, OpenSSL with Ed25519 support):
  python3 reproduce/scripts/verify-containment-lifecycle.py evidence
  python3 reproduce/scripts/test-containment-lifecycle-integrity.py evidence

Run from this directory. These commands perform no inference and launch no
workers. Python optimization mode is refused. Public verification keys are
included. Private signing keys, SSH keys, VM disks and runtime binaries are not.

E2E reproduction requires a separately verified 2.0.1 Linux binary and a suitable
non-root Linux/systemd user environment. Run the command in the report from
reproduce/. The included supervisor source determines the helper protocol
fingerprint; the bundle is not a complete Rust build checkout.

The focused Rust results contain 4 shared-ledger, 6 prepared-call and 3 protected
parent/child tests. Their source hashes and logs are included. To rerun them,
check out the recorded upstream source and use the commands in the report;
focused-test-source/ is reference evidence, not a standalone Cargo workspace.

The outer disposable VM isolated the test laboratory. Workers used native
Landlock. The guest enabled unprivileged namespaces; the host policy was not
changed. External networking was blocked and the VM and private disks removed.

history/ retains fixture-development runs, including earlier errors, an older
10-case run, and a concurrency report-variable correction. They are not extra
passing trials and should not be checked with the final verifier. Only evidence/
is the final qualification. No runtime patch was needed for the tested cases.

This is bounded evidence for the recorded build and deployment. It does not
establish resistance to adaptive attacks, unknown exploits or covert channels,
arbitrary remote-transaction exactly-once behavior, or a compromised host.
A recomputable manifest is not a signature or proof against an operator replacing
all artifacts. The collector and originally provisioned signing keys are trusted.
