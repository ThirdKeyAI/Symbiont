Symbiont 2.0.1 containment evidence — 2026-10-25

Start with summary.json and reproduce/docs/containment-evidence.md.
The evidence directory contains the final 19-case run. The signed manifest hash
is also pinned in the committed documentation on test/containment-evidence.

Offline verification (Python 3.11+, OpenSSL with Ed25519 support):
  python3 reproduce/scripts/verify-containment-evidence.py evidence
  python3 reproduce/scripts/test-containment-evidence-integrity.py evidence
  python3 reproduce/scripts/test-containment-evidence-scoring.py

Run these from the unpacked bundle directory. No model calls or workers are
started by these verification commands. Python optimization mode is refused.

Reproduction requires the separately verified 2.0.1 Linux binary, a suitable
non-root Linux/systemd user environment, and the command in the report. The
supervisor source files are included only for the fixture protocol fingerprint;
no runtime compilation is needed. Private signing keys, SSH keys, VM disks and
the runtime binary are intentionally excluded.

The outer VM was a disposable test laboratory. Workers used native Landlock;
it is not a new VM requirement for Symbiont. The successful guest permitted
unprivileged namespaces while the original host policy refused the setup.

The history directory retains earlier fixture errors; it is not an additional
passing qualification run. boundary-final.json contains separate MCP dispatch
and runtime-loss cleanup results. Do not combine these into an escape rate.

This establishes behavior for fixed probes on the recorded deployment only.
It does not establish resistance to adaptive attackers, unknown kernel/VMM
exploits, hardware covert channels or a compromised host. Approved inference
is a deliberate data channel and carried a synthetic canary in the test.
Checksums cannot authenticate evidence against a host operator able to rewrite
all artifacts. Keep the published manifest hash and test commit separately.
